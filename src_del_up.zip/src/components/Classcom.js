import React, {Component} from 'react'

class Classcom extends Component{
    render() {
        return <h1>Class Components</h1>
    }
}

 export default Classcom