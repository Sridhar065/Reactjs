import react from 'react'

// function Greet(){
//     return <h1>hello Sridhar</h1>
// }


const Greet = () => <h1>Welcome Sridhar</h1>
 
export default Greet