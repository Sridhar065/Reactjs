import React from 'react'
import logo from './logo.svg';
import './App.css';
import Student_form from './student_form';
import Table from './table';
import { BrowserRouter, Route } from "react-router-dom";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
          <Route exact path="/" component={Student_form} />
          <Route exact path="/list" component={Table} />
          
      </BrowserRouter>
    </div>
  );
}





export default App;
